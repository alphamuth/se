#include<stdio.h>
void main(){
//dhchjsdcgh


if()
{
printf("hello >woprks;");
}
else
printf("hello jdfhsj;>>>");
}
