import re
c=0;
c1=0;
blankline=0
fname = raw_input("Enter file name: ")
with open(fname, 'r') as f:
    for line in f:
	print line
	c+=1
	
    	matchObj = re.match( r'[a-z]*if()[a-z]*', line)
	matchObj1=re.match(r'[a-z]*else[a-z*]*',line)
	matchObj2=re.match(r'[a-z]*//[a-z]*',line)
	matchObj3=re.match(r'[a-z]*/\*[a-z]*\*/',line)
	matchObj4=re.match(r'\s',line)
	if matchObj4:
		blankline+=1
	if matchObj2 or matchObj3:
		c-=1
		c1+=1
    	if matchObj or matchObj1:
		c+=1
print "source lines=",c
print "comment lines=",c1
print "blank lines=",blankline

