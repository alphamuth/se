<html>
   <body style="background-color:powderblue;">
      
      <form action="ama.php" method="POST" enctype="multipart/form-data">
         <input type="file" name="image" style="width:120px;color:green;background-color:green;border:2px solid #336600;padding:3px" /><br><br>
         <input type="submit" value ="count" style="width:120px;color:white;background-color:green;border:2px solid #336600;padding:3px"/><br></br>
      </form>
      
   </body>
</html>

<?php 
if(isset($_FILES['image'])){
$file_name = $_FILES['image']['name'];
$python='python';
$command = escapeshellcmd("python count2.py $file_name");
$output = shell_exec($command);
echo '<p style="color:red;font-family:courier;">'.'<b>'. '<marquee direction="scroll">'.$output.'</marquee>'.'</b>'.'</p>';
   }

?>
