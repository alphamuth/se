#include<stdio.h>
#if
#ifdef
void main(){
//dhchjsdcgh


if(i<0){printf("hello >woprks 
"daavfvl,fdv
"dsfawfaef");}
continue;
break;
else
printf("hello jdfhsj;>>>");printf(sum());
else if()
printf("dkcdsm");
a>b?printf("dbhbchw"):printf("jbcjksdnj");
a>b?printf("dbhbchw"):printf("jbcjksdnj");
for(int i=0;i<n;i++){}
int k=0;
while(k<n){k++}
switch(n){case 1:printf("jdjhwen");break; case 2:printf("jdwadncac");break;}
int sum(){return 3+2;}
void sub(){printf("ddjs");} }

