import re
import sys
c=0;
c1=0;
cond=0;
ternary_count=0;
keyword=0;
iteration=0;
function_definitions=0;
cond_prepors=0;
blankline=0
arguments = sys.argv[1]
with open(arguments, 'r') as f:
	for line in f:
		cond1=re.match( r'[a-z]*if\([a-z]*<[0-9]*[a-z]*\)[a-z]*', line)
		cond2=re.match(r'[a-z]*else[a-z*]*',line)
		cond3=re.match(r'[a-z]*>[a-z]\?:*',line)
		itr1=re.match(r'for\(int\s[a-z]*=[0-9]*;[a-z]*\<[0-9]*[a-z]*;[a-z]*\+\+\)',line)
		itr2=re.match(r'while\([a-z]*<[a-z]*[0-9]*\)',line)
		itr3=re.match(r'switch\([a-z]*[0-9]*\)',line)
		key=re.match(r'^(continue)|^(break)|^(goto)|^(return)',line)
		#key=re.match(r'^((?!continue).)*$',line)
		cond_pre=re.match(r'#if|#ifdef|#else',line)
		matchObj2=re.match(r'[a-z]*//[a-z]*',line)
		matchObj3=re.match(r'[a-z]*/\*[a-z]*\*/',line)
		matchObj4=re.match(r'\s',line)
		matchObj5=re.match(r'void|int [a-z]*\(\)',line)
		if cond1 or cond2: 
			cond+=1
		if itr1 or itr2 or itr3:
			iteration+=1
		if cond_pre:
			cond_prepors+=1
		if key:
			keyword+=1;
		if cond3:
			ternary_count+=1;
			cond+=1
			
print("iteration=",iteration)
print("conditional statements=",cond)
print("cond_prepors=",cond_prepors)
print("insensitive words=",keyword)
print("branching=",iteration+cond+cond_prepors)
print("ternary condition=",ternary_count)

