import os
import re
file1=open("story","r");
sentence=0
comp_word=0
tot_words=0
word_count=int(os.popen("wc -w story").read().split()[0])
print("No of words=",word_count)
print("--------------------------------------")
file1cont=file1.read()
sentence+=file1cont.count(".")
sentence+=file1cont.count("?")
sentence+=file1cont.count("!")
print("sentences=",sentence)
print("--------------------------------------")
print("Unique words")
print("-------------------------------------")
print(os.system('cat story |tr " " "\n" | sort | uniq'))
print("------------------------------------------------")
def syllable_count(word):
    word = word.lower()
    count = 0
    vowels = "aeiouy"
    if word[0] in vowels:
        count += 1
    for index in range(1, len(word)):
        if word[index] in vowels and word[index - 1] not in vowels:
            count += 1
    if word.endswith("e"):
        count -= 1
    if count == 0:
        count += 1
    return count
a=[]

with open("story","r") as f:
	for line in f:
		for word in line.split():
			print("word is=",word)
			tot_words+=syllable_count(word)
			print("No of syllables in upper word=",syllable_count(word))
			if syllable_count(word)>3:
				comp_word+=1
print("------------------------------------------------")
print("tot_words=",tot_words)
print("------------------------------------------------")
print("comp_word=",comp_word)
fog_index=0.4*((word_count/sentence)+100*(comp_word/tot_words))
print("------------------------------------------------")
print("fog_index=",fog_index)
