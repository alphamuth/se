<html>
   <body style="background-color:powderblue;">
      
      <form action="ama.php" method="POST" enctype="multipart/form-data">
         <input type="file" name="image" style="width:120px;color:green;background-color:green;border:2px solid #336600;padding:3px" /><br><br>
         <input type="submit" value ="count" style="width:120px;color:white;background-color:green;border:2px solid #336600;padding:3px"/><br></br>
      </form>
      
   </body>
</html>

<?php 
echo '<table style="width:100%">';
if(isset($_FILES['image'])){
$file_name = $_FILES['image']['name'];
$python='python';
$command = escapeshellcmd("python test.py $file_name");
$output = shell_exec($command);
$output1 = explode("\n",$output);
for($i=0;$i<count($output1);$i++)
{	echo '<tr>'.'<td>'.'&nbsp'.$output1[$i].'</td>'.'</tr>';
	
}

//echo '<p style="color:red;font-family:courier;">'.'<b>'. '<marquee direction="scroll">'.$output.'</marquee>'.'</b>'.'</p>';
   }

?>
