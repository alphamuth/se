'''
Assumptions

Java variables not get assigned
'''


import re
import sys
from collections import defaultdict
p=open("Test.java","r")
file=p.read()
method=0;
mem_var=0;
match1=[]
match2=[]
match3=[]
l2=[]
s=[]
dict1= defaultdict(list)
c=0;
mem_var1=[]
with open('Test.java', 'r') as f:
	for line in f:	
		cond1=re.match(r'static int [a-zA-Z]*,[a-zA-Z]*,[a-zA-Z]*',line)
		cond2=re.match(r'static void [a-zA-Z]*\(\)',line)
		'''if cond1:
			mem_var+=1
			match1.append(re.findall(r'static int [a-zA-Z]*,[a-zA-Z]*,[a-zA-Z]*',line))'''
		if cond2:
			method+=1
			l=re.findall(r'static void [a-zA-Z]*\(\)',line)
			l1=''.join(l)
			l2=l1.split(' ')
			s.append(l2[2])
			match2.append(re.findall(r'static void [a-zA-Z]*\(\)',line))
			c=1
			
		elif cond1:
			mem_var+=1
			p=re.findall(r'static int [a-zA-Z]*,[a-zA-Z]*,[a-zA-Z]*',line)
			l1=''.join(p)
			#print l1
			l3=l1.split(' ')
			l4=l3[2].split(',')
			if c==1:
				dict1[s[0]].append(l4)
				s=[]
			else:
				l1=''.join(p)
			#print l1
				l3=l1.split(' ')
				l4=l3[2].split(',')
				mem_var1.append(l4)
			match3.append(re.findall(r'static int [a-zA-Z]*,[a-zA-Z]*,[a-zA-Z]*',line))
flat_list=[]
for sublist in mem_var1:
    for item in sublist:
        flat_list.append(item)
print "Member variables=",flat_list
for keys in dict1:
	l= dict1[keys]
	for i in range(len(l)):
		#print l[i]
		a=set(l[i]) &set(flat_list)
		print "Member methods=",keys
		print "number of variables used=",len(a)
		print "variables used=",a
		
		
		
	
