import java.io.*;
import java.util.*;
public class Test
{
static int a,y,x
static void A()
{
static int a,b,c
}
static void B()
{
static int x,y,z
}
static void C()
{
static int p,q,r
}
}
